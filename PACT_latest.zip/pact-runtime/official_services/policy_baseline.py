"""
Policy baseline service module.
Provides baseline implementations for policy and constraint operations.
"""

from __future__ import annotations


def validate_constraint(payload, constraint):
    """
    Validate payload against simple constraint rules.

    Supported baseline rules:
    - required_keys: list[str]
    - forbidden_keys: list[str]
    """
    if not isinstance(payload, dict):
        return {"valid": False, "violations": ["payload_must_be_object"]}
    if not isinstance(constraint, dict):
        return {"valid": False, "violations": ["constraint_must_be_object"]}

    violations = []

    required_keys = constraint.get("required_keys", [])
    if isinstance(required_keys, list):
        for key in required_keys:
            if isinstance(key, str) and key not in payload:
                violations.append(f"missing_required_key:{key}")

    forbidden_keys = constraint.get("forbidden_keys", [])
    if isinstance(forbidden_keys, list):
        for key in forbidden_keys:
            if isinstance(key, str) and key in payload:
                violations.append(f"forbidden_key_present:{key}")

    return {"valid": len(violations) == 0, "violations": violations}


def gate_constraint(payload, gate):
    """
    Evaluate a payload against a policy gate and return pass/block.

    Supported gate rules: required_keys, forbidden_keys, max_size.
    """
    if not isinstance(payload, dict):
        return {
            "decision": "block",
            "violations": ["payload_must_be_object"],
            "rationale": "Payload is not a dict.",
        }
    if not isinstance(gate, dict):
        return {
            "decision": "block",
            "violations": ["gate_must_be_object"],
            "rationale": "Gate definition is not a dict.",
        }

    rules = gate.get("rules", gate)
    action = gate.get("action", "block")
    violations = []

    for key in rules.get("required_keys") or []:
        if isinstance(key, str) and key not in payload:
            violations.append(f"missing_required_key:{key}")

    payload_labels = (
        payload.get("labels", []) if isinstance(payload.get("labels"), list) else []
    )
    for key in rules.get("forbidden_keys") or []:
        if isinstance(key, str) and (key in payload or key in payload_labels):
            violations.append(f"forbidden_key_present:{key}")

    max_size = rules.get("max_size")
    if isinstance(max_size, (int, float)):
        import json

        size = len(json.dumps(payload))
        if size > max_size:
            violations.append(f"payload_exceeds_max_size:{size}>{int(max_size)}")

    decision = "pass" if not violations else str(action)
    rationale = (
        "All gate rules satisfied."
        if not violations
        else f"{len(violations)} violation(s) detected."
    )
    return {"decision": decision, "violations": violations, "rationale": rationale}


def justify_decision(decision, rules, context=None):
    """
    Justify a policy decision by linking it to applicable rules.
    """
    rules_list = rules if isinstance(rules, list) else []
    applicable = [
        r for r in rules_list if isinstance(r, dict) and r.get("outcome") == decision
    ]
    if not applicable:
        applicable = [r for r in rules_list[:1] if isinstance(r, dict)]

    rule_ids = [r.get("id", "unknown") for r in applicable]
    justification = f"Decision '{decision}' is justified by {len(applicable)} applicable rule(s): {', '.join(rule_ids)}."
    confidence = min(len(applicable) / max(len(rules_list), 1), 1.0)

    return {
        "justification": justification,
        "applicable_rules": applicable,
        "confidence": round(confidence, 3),
    }


def classify_risk(action, categories=None):
    """
    Classify the risk level of an action based on heuristic indicators.
    """
    cats = (
        categories
        if isinstance(categories, list) and categories
        else ["low", "medium", "high", "critical"]
    )
    if not isinstance(action, dict):
        return {
            "risk_level": cats[0],
            "factors": [],
            "rationale": "Action is not a dict; defaulting to lowest risk.",
        }

    factors = []
    score = 0

                                                             
    if action.get("destructive") or action.get("irreversible"):
        factors.append("destructive_or_irreversible")
        score += 2
    if action.get("external") or action.get("public"):
        factors.append("external_exposure")
        score += 1
    if action.get("involves_pii") or action.get("pii"):
        factors.append("pii_involvement")
        score += 1
    if (
        action.get("cost")
        and isinstance(action["cost"], (int, float))
        and action["cost"] > 100
    ):
        factors.append("high_cost")
        score += 1

                                     
                         
    _high_risk_labels = {"security", "breaking-change", "destructive", "database"}
    _critical_labels = {"hardcoded-secret", "skip-tests", "skip-review"}
    labels = action.get("labels") if isinstance(action.get("labels"), list) else []
    label_score = sum(
        2 if lbl in _critical_labels else 1 if lbl in _high_risk_labels else 0
        for lbl in labels
    )
    if label_score:
        factors.append(f"risk_labels:{label_score}pts")
        score += min(label_score, 2)

                                                                
    if "CVE" in str(action.get("diff_text", "")):
        factors.append("cve_reference_in_diff")
        score += 2

                            
    if action.get("target_environment") == "prod":
        factors.append("production_target")
        score += 1

                                                                       
    _critical_path_patterns = [
        "router",
        "middleware",
        "/core/",
        "auth/",
        "gateway",
        "security/",
    ]
    for f in action.get("changed_files") or []:
        if any(p in str(f) for p in _critical_path_patterns):
            factors.append(f"critical_path_file:{f}")
                                                                
            score += 2 if action.get("target_environment") == "prod" else 1
            break              

    idx = min(score, len(cats) - 1)
    risk_level = cats[idx]
    rationale = (
        f"Risk classified as '{risk_level}' based on {len(factors)} factor(s): {', '.join(factors)}."
        if factors
        else f"No risk factors detected; classified as '{risk_level}'."
    )

    return {"risk_level": risk_level, "factors": factors, "rationale": rationale}


def score_risk(action, dimensions=None):
    """
    Compute a numeric risk score for an action across policy dimensions.
    """
    dims = (
        dimensions
        if isinstance(dimensions, list) and dimensions
        else [
            "data_exposure",
            "reversibility",
            "blast_radius",
        ]
    )
    if not isinstance(action, dict):
        return {
            "risk_score": 0.0,
            "dimension_scores": {d: 0.0 for d in dims},
            "safe": True,
        }

    dim_scores = {}
    for dim in dims:
        d = str(dim).lower()
        if d in ("data_exposure", "pii"):
            dim_scores[d] = (
                0.7 if action.get("involves_pii") or action.get("pii") else 0.1
            )
        elif d == "reversibility":
            dim_scores[d] = (
                0.8 if action.get("irreversible") or action.get("destructive") else 0.1
            )
        elif d == "blast_radius":
            dim_scores[d] = (
                0.6 if action.get("external") or action.get("public") else 0.2
            )
        else:
            dim_scores[d] = 0.2

    risk_score = round(max(dim_scores.values()) if dim_scores else 0.0, 3)
    return {
        "risk_score": risk_score,
        "dimension_scores": {k: round(v, 3) for k, v in dim_scores.items()},
        "safe": risk_score < 0.5,
    }


def evaluate_decision(decision_context, violations=None, risk=None):
    """Evaluate a policy decision from context, violations, and risk signals."""
    context = decision_context if isinstance(decision_context, dict) else {}
    violation_items = violations if isinstance(violations, list) else []
    risk_obj = risk if isinstance(risk, dict) else {}

    action = context.get("action") if isinstance(context.get("action"), dict) else {}
    resource = (
        context.get("resource") if isinstance(context.get("resource"), dict) else {}
    )

    flags = []
    conditions = []
    transforms = []

    if violation_items:
        flags.append(f"violations:{len(violation_items)}")
        if any("pii" in str(item).lower() for item in violation_items):
            conditions.append("redact_pii")
            transforms.append("redact_pii")
        if any("secret" in str(item).lower() for item in violation_items):
            conditions.append("remove_secret_material")

    if action.get("destructive") or action.get("irreversible"):
        flags.append("destructive_action")
        conditions.append("require_human_review")
    if action.get("external") or action.get("public"):
        flags.append("external_exposure")
        conditions.append("log_execution")
    if action.get("involves_pii") or action.get("pii"):
        flags.append("pii_involved")
        conditions.append("redact_pii")
        transforms.append("redact_pii")

    sensitivity = str(resource.get("sensitivity_level", "")).lower()
    if sensitivity in {"restricted", "critical"}:
        flags.append(f"resource_sensitivity:{sensitivity}")
        conditions.append("require_human_review")

    risk_score = 0.0
    if isinstance(risk_obj.get("risk_score"), (int, float)):
        risk_score = float(risk_obj["risk_score"])
    elif isinstance(risk_obj.get("dimension_scores"), dict):
        dim_scores = [
            float(v)
            for v in risk_obj["dimension_scores"].values()
            if isinstance(v, (int, float))
        ]
        risk_score = max(dim_scores) if dim_scores else 0.0

    score = len(flags) + (2 if risk_score >= 0.75 else 1 if risk_score >= 0.5 else 0)
    if score >= 4:
        decision = "deny"
    elif score >= 2:
        decision = "conditional_allow"
    elif score == 1:
        decision = "escalate"
    else:
        decision = "allow"

    rationale_bits = []
    if flags:
        rationale_bits.append(f"{len(flags)} policy signal(s)")
    if risk_score:
        rationale_bits.append(f"risk={round(risk_score, 3)}")
    if not rationale_bits:
        rationale_bits.append("no policy blockers detected")

    evidence = {
        "principal": context.get("principal"),
        "action": action or context.get("action"),
        "resource": resource or context.get("resource"),
        "violations": violation_items,
        "risk": risk_obj,
        "flags": flags,
    }

    return {
        "decision": decision,
        "conditions": sorted(set(conditions)),
        "transforms": sorted(set(transforms)),
        "evidence": evidence,
        "risk": risk_obj,
        "rationale": "; ".join(rationale_bits),
    }


def classify_record(record, context=None):
    """Classify a record's policy sensitivity."""
    rec = record if isinstance(record, dict) else {}
    ctx = context if isinstance(context, dict) else {}

    labels = rec.get("labels") if isinstance(rec.get("labels"), list) else []
    fields = rec.get("fields") if isinstance(rec.get("fields"), dict) else {}
    destination = str(rec.get("destination", ctx.get("destination", ""))).lower()

    categories = []
    category_pool = {
        "pii": ["pii", "ssn", "email", "phone", "customer"],
        "financial": ["financial", "invoice", "payment", "bank", "billing"],
        "legal": ["legal", "contract", "attorney", "case"],
        "security": ["security", "credential", "secret", "token", "key"],
    }
    search_space = " ".join(
        [str(rec.get("type", "")), destination] + [str(x) for x in labels]
    )
    search_space = f"{search_space} {fields}"

    for category, hints in category_pool.items():
        if any(hint in search_space.lower() for hint in hints):
            categories.append(category)

    score = len(categories)
    if destination in {"external", "public"}:
        score += 1
    if rec.get("critical") or ctx.get("critical"):
        score += 1

    if score >= 4:
        sensitivity_level = "critical"
    elif score == 3:
        sensitivity_level = "restricted"
    elif score == 2:
        sensitivity_level = "confidential"
    elif score == 1:
        sensitivity_level = "internal"
    else:
        sensitivity_level = "public"

    sensitivity_score = round(min(score * 0.25, 1.0), 3)
    rationale = (
        f"Record classified as {sensitivity_level} due to categories: {', '.join(categories)}."
        if categories
        else f"No sensitive categories detected; classified as {sensitivity_level}."
    )
    evidence = {
        "labels": labels,
        "fields": list(fields.keys()),
        "destination": destination or None,
        "context": ctx,
    }

    return {
        "sensitivity_level": sensitivity_level,
        "categories": categories,
        "sensitivity_score": sensitivity_score,
        "rationale": rationale,
        "evidence": evidence,
    }
