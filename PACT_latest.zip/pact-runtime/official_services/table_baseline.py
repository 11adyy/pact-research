"""
Table baseline service module.
Provides baseline implementations for table-related capabilities.
"""


def filter_table(table_data, filter_criteria):
    """
    Filter table data based on criteria.

    Args:
        table_data (list): The table data as a list of rows.
        filter_criteria (dict): The filter criteria.

    Returns:
        dict: {"filtered_table": list}
    """
                                                             
    return {"table": table_data}


def sort_table(table_data, sort_by):
    """
    Sort table rows by one or more columns.

    Args:
        table_data (list): Table rows as list of dicts.
        sort_by (list): Sort specs, each with 'field' and optional 'order'.

    Returns:
        dict: {"table": list}
    """
    if not isinstance(table_data, list) or not table_data:
        return {"table": table_data or []}
    if not isinstance(sort_by, list) or not sort_by:
        return {"table": table_data}

                                                                          
    result = list(table_data)
    for spec in reversed(sort_by):
        field = spec.get("field", "")
        descending = spec.get("order", "asc").lower() == "desc"
        result.sort(
            key=lambda row, f=field: (row.get(f) is None, row.get(f, "")),
            reverse=descending,
        )

    return {"table": result}


def aggregate_table(table_data, aggregations, group_by=None):
    """
    Compute aggregate values over table columns.

    Args:
        table_data (list): Table rows as list of dicts.
        aggregations (list): Each has 'field' and 'function' (sum/avg/min/max/count).
        group_by (str): Optional column to group by.

    Returns:
        dict: {"results": list, "row_count": int}
    """
    if not isinstance(table_data, list):
        return {"results": [], "row_count": 0}
    if not isinstance(aggregations, list) or not aggregations:
        return {"results": [], "row_count": len(table_data)}

                
    groups = {}
    for row in table_data:
        key = row.get(group_by, "__all__") if group_by else "__all__"
        groups.setdefault(key, []).append(row)

    results = []
    for key, rows in groups.items():
        entry = {}
        if group_by:
            entry[group_by] = key
        for agg in aggregations:
            field = agg.get("field", "")
            func = agg.get("function", "count").lower()
            values = [r.get(field) for r in rows if r.get(field) is not None]
            numeric = [v for v in values if isinstance(v, (int, float))]
            result_key = f"{field}_{func}"
            if func == "count":
                entry[result_key] = len(values)
            elif func == "sum":
                entry[result_key] = sum(numeric) if numeric else 0
            elif func == "avg":
                entry[result_key] = (
                    round(sum(numeric) / len(numeric), 2) if numeric else 0
                )
            elif func == "min":
                entry[result_key] = min(numeric) if numeric else None
            elif func == "max":
                entry[result_key] = max(numeric) if numeric else None
            else:
                entry[result_key] = None
        results.append(entry)

    return {"results": results, "row_count": len(table_data)}


def read_sheet(path, sheet_name=None, range=None):
    """Read a CSV/Excel file into rows (baseline: CSV only)."""
    import csv
    from pathlib import Path as _Path

    p = _Path(path)
    if not p.exists():
        return {
            "table": [],
            "headers": [],
            "row_count": 0,
            "error": f"File not found: {path}",
        }

    rows = []
    try:
        with open(p, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
    except Exception as e:
        return {"table": [], "headers": [], "row_count": 0, "error": str(e)}

    return {
        "table": rows,
        "row_count": len(rows),
        "headers": list(rows[0].keys()) if rows else [],
    }


def write_sheet(path, table, headers=None, sheet_name=None):
    """Write rows to a CSV file (baseline: CSV only)."""
    import csv
    from pathlib import Path as _Path

    p = _Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    if not table:
        return {"written": False, "row_count": 0, "path": str(p)}

    cols = headers or list(table[0].keys()) if table else []
    try:
        with open(p, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=cols)
            writer.writeheader()
            for row in table:
                writer.writerow({k: row.get(k, "") for k in cols})
    except Exception as e:
        return {"written": False, "row_count": 0, "path": str(p), "error": str(e)}

    return {"written": True, "row_count": len(table), "path": str(p)}
