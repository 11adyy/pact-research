"""
Image baseline service module.
Provides baseline implementations for image-related capabilities.
"""

from pathlib import Path


def _load_image_bytes(image_data):
    """Load bytes directly or from a local file path."""
    if isinstance(image_data, (bytes, bytearray)):
        return bytes(image_data), None

    if isinstance(image_data, str):
        source = image_data.strip()
        if not source:
            return None, None

        path = Path(source)
        if path.is_file():
            return path.read_bytes(), str(path)
        return None, None

    return None, None


def _infer_image_kind(payload):
    """Infer a basic image format from magic bytes."""
    if payload.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG"
    if payload.startswith(b"\xff\xd8\xff"):
        return "JPEG"
    if payload.startswith(b"GIF87a") or payload.startswith(b"GIF89a"):
        return "GIF"
    return "unknown"


def generate_caption(image_data):
    """
    Generate a caption for an image.

    Args:
        image_data (bytes): The image data.

    Returns:
        dict: {"caption": str}
    """
                                                                                   
    if image_data is None:
        return {"caption": "An image with no readable content."}

    payload, source_path = _load_image_bytes(image_data)
    if payload is not None:
        size = len(payload)
        if size == 0:
            return {"caption": "An empty image payload."}
        image_kind = _infer_image_kind(payload)
        if source_path:
            return {
                "caption": f"A {image_kind} image loaded from '{source_path}' containing {size} bytes."
            }
        return {"caption": f"A {image_kind} image payload containing {size} bytes."}

    source = str(image_data).strip()
    if not source:
        return {"caption": "An image with no readable content."}
    return {"caption": f"An image referenced by: {source}."}


def classify_image(image_data):
    """
    Classify an image.

    Args:
        image_data (bytes): The image data.

    Returns:
        dict: {"class": str, "confidence": float}
    """
                                          
    return {"label": "unknown", "confidence": 0.0}


def extract_text(image_data, language=None):
    """
    OCR baseline: extract text from an image.

    The baseline cannot perform real OCR — it returns a placeholder
    describing the input. Production bindings should use Tesseract,
    Azure Vision, or similar.

    Args:
        image_data: Image bytes or file path string.
        language (str): Language hint (unused in baseline).

    Returns:
        dict: {"text": str, "confidence": float, "regions": list}
    """
    lang = language or "en"
    payload, source_path = _load_image_bytes(image_data)

    if payload is not None:
        size = len(payload)
        kind = _infer_image_kind(payload)
        source_desc = f"'{source_path}'" if source_path else "in-memory"
        return {
            "text": f"[OCR baseline] {kind} image from {source_desc} ({size} bytes, lang={lang}). Real OCR requires a production binding.",
            "confidence": 0.0,
            "regions": [],
        }

    return {
        "text": f"[OCR baseline] No readable image payload (lang={lang}). Real OCR requires a production binding.",
        "confidence": 0.0,
        "regions": [],
    }


def generate_image(prompt, style=None, size=None):
    """Generate an image from a text prompt (baseline: returns placeholder)."""
    return {
        "image": None,
        "format": "png",
        "prompt": prompt,
        "style": style or "default",
        "size": size or "512x512",
        "_fallback": True,
        "message": "Baseline image generation requires a production binding (DALL-E, Stable Diffusion, etc.).",
    }
