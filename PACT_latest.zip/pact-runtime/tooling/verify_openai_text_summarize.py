#!/usr/bin/env python3

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REGISTRY_ROOT = ROOT.parent / "pact-registry"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from customer_facing.neutral_api import NeutralRuntimeAPI

_BINDING_ID = "openapi_doc_generate_openai_chat"
_SERVICE_ID = "model_openai_chat"


def _write_active_binding(host_root: Path) -> None:
    state_dir = host_root / ".pact-runtime"
    state_dir.mkdir(parents=True, exist_ok=True)
    payload = {"doc.content.generate": _BINDING_ID}
    (state_dir / "active_bindings.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Define it in your shell before running this verifier."
        )

    sample_instruction = (
        "Write a concise markdown status note about OpenAPI runtime health."
    )

    with tempfile.TemporaryDirectory(prefix="pact-runtime-openai-") as tmpdir:
        host_root = Path(tmpdir)
        _write_active_binding(host_root)

        api = NeutralRuntimeAPI(
            registry_root=REGISTRY_ROOT,
            runtime_root=ROOT,
            host_root=host_root,
        )
        result = api.execute_capability(
            "doc.content.generate",
            {
                "instruction": sample_instruction,
                "context": "Live verifier run",
                "format": "markdown",
            },
        )

    outputs = result.get("outputs") or {}
    meta = result.get("meta", {})

    document = outputs.get("document")
    if not isinstance(document, str) or not document.strip():
        raise RuntimeError(f"OpenAI doc.generate returned invalid document: {outputs!r}")

    if meta.get("binding_id") != _BINDING_ID:
        raise RuntimeError(
            f"Expected binding_id '{_BINDING_ID}', got '{meta.get('binding_id')}'."
        )

    if meta.get("service_id") != _SERVICE_ID:
        raise RuntimeError(
            f"Expected service_id '{_SERVICE_ID}', got '{meta.get('service_id')}'."
        )

    print("OpenAI doc.content.generate verification passed.")
    print(f"Document preview: {document[:160]!r}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
